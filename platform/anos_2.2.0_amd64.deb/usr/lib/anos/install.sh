#!/bin/sh
# Native installer / upgrader for one AnOS instance (contracts/runtime/v0.md).
#
#   install.sh <instance> [--runtime rust] [--port 9081] [--tls https|http-local|http-lan] [--listen ADDR] [--tls-names LIST]
#              [--dev-tools|--no-dev-tools] [--allow-platform-downgrade]
#              [--model-provider none|local|anthropic] [--model-key-file PATH] [--model-id ID]
#              [--model-endpoint URL] [--model-class local|cloud] [--catalog DIR|URL]
#
# The native v2 (Rust) runtime is the only one (ADR 0054; --runtime rust is accepted and is the default, v1 and its
# Go runtime are on the branch release/v1). ANOS_PREBUILT_DIR is required: a directory (the .deb's /usr/lib/anos,
# used by anos-instance, or tools/dev/browser-payload.sh's) with bin/anos-core-v2, bin/anos-agent-v2 and a
# separately built ui/index.html. Nothing is built; no sample app and no development tools are installed; the
# PostgreSQL cluster's real port is found. Use a verified payload. Re-run with the desired payload for upgrades and
# compatible rollbacks; an instance of v1 (Go runtime) or 2.0.x is upgraded the same way. Existing instance settings
# are retained. Changes require a separate operator action.
#
# Apps (docs/adr/0051): the platform has no built-in apps. The installer trusts the official keys of
# <dir>/trust/ (catalog.pub in catalog-trust/, publisher.pub in trust/ and agent-trust/), sets ANOS_CATALOG_SOURCE to
# the official catalog unless core.env already names one or --catalog is given (an absolute directory holding a
# signed copy of a catalog, or an https:// base URL), and once Core is healthy runs
# `anos-core appstore bootstrap` for the baseline apps (Store, Accounts, Settings, Notifications, Files). An upgrade
# from 2.0.2 removes the built-in app manifests and standalone pages only after that succeeded. When it fails the
# instance runs without the missing apps (or keeps its built-in ones) and the result is PARTIAL baseline-missing;
# `anos-instance apps <instance>` retries.
#
# TLS (contracts/runtime/tls-v1.md): a new instance serves HTTPS on all interfaces with the installation's own
# CA (/etc/anos/<inst>/tls/ca.crt, to be trusted on every device). An upgrade keeps the mode, listen address and
# names in core.env; an instance from before TLS keeps plain HTTP on loopback. --tls http-local is loopback HTTP
# (development); --tls http-lan is plain HTTP on the network, with a warning.
#
# Platform (docs/adr/0004): Debian 13 is supported, Ubuntu 24.04 is the provisional development platform;
# systemd >= 255 and PostgreSQL >= 16 are required. ANOS_ALLOW_UNSUPPORTED_OS=1 lets a prebuilt install
# continue on another distribution.
#
# Model gateway (contracts/core-api/model-v1.md section 7): --model-provider selects at most one real provider;
# the default is none, so the Assistant reports itself unavailable. local is an OpenAI-compatible server on
# loopback (Ollama, llama.cpp; --model-id required, --model-endpoint default Ollama's loopback URL,
# --model-class cloud for a server elsewhere over https), anthropic the Anthropic Messages API. The key file is
# created by the operator (one line, root:anos-<inst> 0640, e.g. /etc/anos/<inst>/keys/model.key); the installer
# only records its path and checks its mode, it never reads, prints or creates a key. An upgrade keeps the
# ANOS_MODEL_* settings of core.env; --model-provider none removes them.
#
# PostgreSQL port: ANOS_PG_PORT, else the port in an existing core.env, else the online cluster of pg_lsclusters
# or 5432.
#
# Run as root inside the Linux host (WSL: wsl -d AnOS-Test -u root -- bash .../install.sh <inst>).
# Idempotent: running it again upgrades binaries, UI and units and keeps keys,
# the installation id, the database and its password.
#
# Exit status: 0 complete, 1 failed, 3 partial (agent installed, but anos-core
# could not be started, or the baseline apps could not be installed
# from the catalog: tag baseline-missing; the reason and the retry command are printed).
set -eu
umask 022

say()  { printf '%s\n' "install: $*"; }
warn() { printf '%s\n' "install: WARNING: $*" >&2; }
die()  { printf '%s\n' "install: ERROR: $*" >&2; exit 1; }
usage() { printf '%s\n' "usage: install.sh <instance> [--runtime rust] [--port 9081] [--tls https|http-local|http-lan] [--listen ADDR] [--tls-names LIST] [--dev-tools|--no-dev-tools] [--allow-platform-downgrade] [--model-provider none|local|anthropic] [--model-key-file PATH] [--model-id ID] [--model-endpoint URL] [--model-class local|cloud] [--catalog DIR|URL]" >&2; exit 2; }

INST=""
RUNTIME=rust
PORT=""
TLS_MODE=""
LISTEN=""
TLS_NAMES=""
V2_TLS_NAMES_SET=0
DEV_TOOLS=""
ALLOW_PLATFORM_DOWNGRADE=0
MODEL_PROVIDER=""
MODEL_OPTIONS=0
MODEL_KEY_FILE=""
MODEL_ID=""
MODEL_ENDPOINT=""
MODEL_CLASS=""
CATALOG_OPT=""
while [ $# -gt 0 ]; do
	case "$1" in
		--runtime) [ $# -ge 2 ] || usage; RUNTIME=$2; shift 2 ;;
		--runtime=*) RUNTIME=${1#--runtime=}; shift ;;
		--port) [ $# -ge 2 ] || usage; PORT=$2; shift 2 ;;
		--port=*) PORT=${1#--port=}; shift ;;
		--tls) [ $# -ge 2 ] || usage; TLS_MODE=$2; shift 2 ;;
		--tls=*) TLS_MODE=${1#--tls=}; shift ;;
		--listen) [ $# -ge 2 ] || usage; LISTEN=$2; shift 2 ;;
		--listen=*) LISTEN=${1#--listen=}; shift ;;
		--tls-names) V2_TLS_NAMES_SET=1; [ $# -ge 2 ] || usage; TLS_NAMES=$2; shift 2 ;;
		--tls-names=*) V2_TLS_NAMES_SET=1; TLS_NAMES=${1#--tls-names=}; shift ;;
		--dev-tools) DEV_TOOLS=1; shift ;;
		--no-dev-tools) DEV_TOOLS=0; shift ;;
		--allow-platform-downgrade) ALLOW_PLATFORM_DOWNGRADE=1; shift ;;
		--model-provider) MODEL_OPTIONS=1; [ $# -ge 2 ] || usage; MODEL_PROVIDER=$2; shift 2 ;;
		--model-provider=*) MODEL_OPTIONS=1; MODEL_PROVIDER=${1#--model-provider=}; shift ;;
		--model-key-file) MODEL_OPTIONS=1; [ $# -ge 2 ] || usage; MODEL_KEY_FILE=$2; shift 2 ;;
		--model-key-file=*) MODEL_OPTIONS=1; MODEL_KEY_FILE=${1#--model-key-file=}; shift ;;
		--model-id) MODEL_OPTIONS=1; [ $# -ge 2 ] || usage; MODEL_ID=$2; shift 2 ;;
		--model-id=*) MODEL_OPTIONS=1; MODEL_ID=${1#--model-id=}; shift ;;
		--model-endpoint) MODEL_OPTIONS=1; [ $# -ge 2 ] || usage; MODEL_ENDPOINT=$2; shift 2 ;;
		--model-endpoint=*) MODEL_OPTIONS=1; MODEL_ENDPOINT=${1#--model-endpoint=}; shift ;;
		--model-class) MODEL_OPTIONS=1; [ $# -ge 2 ] || usage; MODEL_CLASS=$2; shift 2 ;;
		--model-class=*) MODEL_OPTIONS=1; MODEL_CLASS=${1#--model-class=}; shift ;;
		--catalog) [ $# -ge 2 ] || usage; CATALOG_OPT=$2; shift 2 ;;
		--catalog=*) CATALOG_OPT=${1#--catalog=}; shift ;;
		-h|--help) usage ;;
		-*) usage ;;
		*) [ -z "$INST" ] || usage; INST=$1; shift ;;
	esac
done
[ -n "$INST" ] || usage
case "$RUNTIME" in
	rust) ;;
	go) die "--runtime go: AnOS 2 has only the Rust runtime (ADR 0054); v1 is on the branch release/v1. Upgrade a v1 instance with --runtime rust" ;;
	*) usage ;;
esac
# --catalog: an absolute directory with a signed copy of a catalog, or an https:// base URL (catalog-v1.md section 5).
case "$CATALOG_OPT" in
	'') ;;
	https://*)
		printf '%s' "$CATALOG_OPT" | grep -Eqx 'https://[A-Za-z0-9.-]+(:[0-9]{1,5})?(/[A-Za-z0-9._~/-]*)?' ||
			die "--catalog must be an https:// URL without credentials, query or spaces, or an absolute directory" ;;
	/*)
		printf '%s' "$CATALOG_OPT" | grep -Eqx '/[A-Za-z0-9._/-]{0,255}' ||
			die "--catalog directory must be an absolute path of letters, digits and . _ - /"
		[ -d "$CATALOG_OPT" ] || die "--catalog $CATALOG_OPT is not a directory"
		# Core runs with PrivateTmp and ProtectHome: it cannot read a catalog there.
		case "$CATALOG_OPT/" in
			/tmp/*|/var/tmp/*|/home/*|/root/*|/run/user/*)
				die "--catalog $CATALOG_OPT is hidden from Core (PrivateTmp, ProtectHome); copy the catalog to a directory such as /srv or /var/lib" ;;
		esac ;;
	*) die "--catalog must be an https:// URL or an absolute directory" ;;
esac
printf '%s' "$INST" | grep -Eqx '[a-z][a-z0-9]{0,15}' ||
	die "instance name '$INST' must match [a-z][a-z0-9]{0,15}"
[ "$(id -u)" = 0 ] || die "must run as root"

CORE_USER="anos-$INST"
APPS_GROUP="anos-$INST-apps"
OPT="/opt/anos/$INST"
ETC="/etc/anos/$INST"
VAR="/var/lib/anos/$INST"
RUN="/run/anos/$INST"
DB="anos_$INST"
DB_ROLE="anos_${INST}_core"

# Serialize current installers of this instance from configuration reads
# through activation, without stopping the running Core to check compatibility.
install -d -m 0700 -o root -g root /run/anos-install
exec 9>"/run/anos-install/$INST.lock"
flock -x -w 60 9 || die "another installer is running for $INST"

V2_UNIT_HEADER='# Managed by the AnOS v2 installer.'
PREBUILT=${ANOS_PREBUILT_DIR:-}
REQUESTED_DEV_TOOLS=$DEV_TOOLS
[ -n "$PREBUILT" ] || die "ANOS_PREBUILT_DIR is required (the .deb's /usr/lib/anos, or tools/dev/browser-payload.sh)"
CORE_ARTIFACT=anos-core-v2
AGENT_ARTIFACT=anos-agent-v2
INSTALL_DIR=$(cd "$(dirname "$0")" && pwd)
if [ -d "$INSTALL_DIR/deploy/systemd/v2" ]; then
	# Installed package: templates are private to this version of the installer.
	INSTALL_ROOT=$INSTALL_DIR
	. "$INSTALL_DIR/runtime-v2.sh"
else
	INSTALL_ROOT=$(cd "$INSTALL_DIR/../.." && pwd)
	. "$INSTALL_ROOT/tools/install/runtime-v2.sh"
fi
PREBUILT=$(cd "$PREBUILT" 2>/dev/null && pwd) || die "ANOS_PREBUILT_DIR=${ANOS_PREBUILT_DIR} is not a directory"
for f in "bin/$CORE_ARTIFACT" "bin/$AGENT_ARTIFACT"; do
	[ -x "$PREBUILT/$f" ] || die "ANOS_PREBUILT_DIR: $PREBUILT/$f is missing"
done
[ -f "$PREBUILT/ui/index.html" ] || die "ANOS_PREBUILT_DIR: $PREBUILT/ui/index.html is missing"
[ "$DEV_TOOLS" != 1 ] || die "--dev-tools is not available for a prebuilt install"
DEV_TOOLS=0

env_value() { # env_value <NAME>: value of NAME in the existing core.env, or nothing
	[ -f "$ETC/core.env" ] || return 0
	sed -n "s/^$1=//p" "$ETC/core.env" | head -n 1
}

v2_preflight_files

# ---- platform (docs/adr/0004) ------------------------------------------------
OS_ID=""
OS_VER=""
if [ -r /etc/os-release ]; then
	OS_ID=$(. /etc/os-release && printf '%s' "${ID:-}")
	OS_VER=$(. /etc/os-release && printf '%s' "${VERSION_ID:-}")
fi
unsupported() {
	if [ "${ANOS_ALLOW_UNSUPPORTED_OS:-0}" != 1 ]; then
		die "$1 is not a supported platform (Debian 13 amd64; docs/adr/0004). ANOS_ALLOW_UNSUPPORTED_OS=1 continues anyway"
	fi
	warn "$1 is not a supported platform (Debian 13 amd64; docs/adr/0004)"
}
case "$OS_ID:$OS_VER" in
	debian:13) ;;
	ubuntu:24.04) warn "Ubuntu 24.04 is the development platform (provisional, not supported; docs/adr/0004)" ;;
	*) unsupported "${OS_ID:-unknown} ${OS_VER:-?}" ;;
esac
[ "$(uname -m)" = x86_64 ] || unsupported "architecture $(uname -m)"
SYSTEMD_VER=$(systemctl --version 2>/dev/null | sed -n '1s/^systemd \([0-9][0-9]*\).*/\1/p')
[ -n "$SYSTEMD_VER" ] || die "cannot read the systemd version (systemctl --version)"
[ "$SYSTEMD_VER" -ge 255 ] || die "systemd $SYSTEMD_VER is too old: AnOS needs 255 or later"

# ---- PostgreSQL port ---------------------------------------------------------
PG_PORT=${ANOS_PG_PORT:-}
if [ -z "$PG_PORT" ]; then
	PG_PORT=$(env_value ANOS_DATABASE_URL | sed -n 's|^postgres://[^@]*@[^:/]*:\([0-9][0-9]*\)/.*|\1|p')
fi
if [ -z "$PG_PORT" ]; then
	if command -v pg_lsclusters >/dev/null 2>&1; then
		# "16 main 5432 online postgres ..." : the newest online cluster of version 16 or later.
		PG_PORT=$(pg_lsclusters -h 2>/dev/null | awk '$4 ~ /^online/ && $1+0 >= 16 {print $1, $3}' | sort -n | tail -n 1 | cut -d' ' -f2)
		n_online=$(pg_lsclusters -h 2>/dev/null | awk '$4 ~ /^online/ && $1+0 >= 16' | wc -l)
		[ "$n_online" -le 1 ] || warn "several PostgreSQL clusters are online; using port $PG_PORT (set ANOS_PG_PORT to choose)"
	fi
	PG_PORT=${PG_PORT:-5432}
fi
printf '%s' "$PG_PORT" | grep -Eqx '[0-9]{2,5}' || die "PostgreSQL port '$PG_PORT' is not a number"
RESERVED_PORTS="8081 8082 8881 8882 $PG_PORT"

# ---- port ----------------------------------------------------------------
if [ -z "$PORT" ] && [ -f "$ETC/core.env" ]; then
	PORT=$(sed -n 's/^ANOS_HTTP_ADDR=.*:\([0-9][0-9]*\)$/\1/p' "$ETC/core.env" | head -n 1)
fi
PORT=${PORT:-9081}
printf '%s' "$PORT" | grep -Eqx '[0-9]{4,5}' || die "--port must be a number between 1024 and 65535"
{ [ "$PORT" -ge 1024 ] && [ "$PORT" -le 65535 ]; } || die "--port must be between 1024 and 65535"
for p in $RESERVED_PORTS; do
	[ "$PORT" -ne "$p" ] || die "port $p is reserved and cannot be used by AnOS"
done
if [ -n "$(ss -ltnH "sport = :$PORT" 2>/dev/null)" ] &&
	! systemctl is-active --quiet "anos-core@$INST.service"; then
	die "port $PORT is already in use by another program"
fi

# ---- development tools -------------------------------------------------------
if [ -z "$DEV_TOOLS" ]; then
	if [ -f "$ETC/core.env" ]; then
		DEV_TOOLS=0
		[ "$(env_value ANOS_DEV_TOOLS)" != 1 ] || DEV_TOOLS=1
	else
		DEV_TOOLS=1
	fi
fi

# ---- model gateway provider (contracts/core-api/model-v1.md section 7) ---------
# An upgrade keeps the ANOS_MODEL_* settings of core.env; options given replace the stored ones. Switching to another
# provider keeps none of the old one's settings, and --model-provider none clears them all.
STORED_PROVIDER=$(env_value ANOS_MODEL_PROVIDER)
# core.env from before ANOS_MODEL_PROVIDER: a key file alone meant the Anthropic adapter (modelgw.ProvidersFromEnv).
[ -n "$STORED_PROVIDER" ] || [ -z "$(env_value ANOS_MODEL_KEY_FILE)" ] || STORED_PROVIDER=anthropic
MODEL_PROVIDER=${MODEL_PROVIDER:-${STORED_PROVIDER:-none}}
case "$MODEL_PROVIDER" in
	none|local|anthropic) ;;
	*) die "--model-provider must be none, local or anthropic" ;;
esac
if [ "$MODEL_PROVIDER" = none ]; then
	[ -z "$MODEL_KEY_FILE$MODEL_ID$MODEL_ENDPOINT$MODEL_CLASS" ] ||
		die "--model-key-file, --model-id, --model-endpoint and --model-class need --model-provider local or anthropic"
elif [ "$MODEL_PROVIDER" = "$STORED_PROVIDER" ]; then
	[ -n "$MODEL_KEY_FILE" ] || MODEL_KEY_FILE=$(env_value ANOS_MODEL_KEY_FILE)
	[ -n "$MODEL_ID" ] || MODEL_ID=$(env_value ANOS_MODEL_ID)
	[ -n "$MODEL_ENDPOINT" ] || MODEL_ENDPOINT=$(env_value ANOS_MODEL_ENDPOINT)
	[ -n "$MODEL_CLASS" ] || MODEL_CLASS=$(env_value ANOS_MODEL_CLASS)
fi
[ -z "$MODEL_KEY_FILE" ] || printf '%s' "$MODEL_KEY_FILE" | grep -Eqx '/[A-Za-z0-9._/-]{1,255}' ||
	die "--model-key-file must be an absolute path of letters, digits and . _ - /"
[ -z "$MODEL_ID" ] || printf '%s' "$MODEL_ID" | grep -Eqx '[A-Za-z0-9._:-]{1,128}' ||
	die "--model-id must be 1-128 of letters, digits and . _ : -"
[ -z "$MODEL_ENDPOINT" ] || printf '%s' "$MODEL_ENDPOINT" | grep -Eqx 'https?://([A-Za-z0-9.-]+|\[[0-9a-fA-F:]+\])(:[0-9]{1,5})?(/[A-Za-z0-9._~/-]*)?' ||
	die "--model-endpoint must be an http(s) URL without credentials, query or spaces"
case "$MODEL_CLASS" in
	''|local|cloud) ;;
	*) die "--model-class must be local or cloud" ;;
esac
case "$MODEL_PROVIDER" in
	local)
		[ -n "$MODEL_ID" ] || die "--model-provider local needs --model-id (the model as the local server names it)"
		if [ "${MODEL_CLASS:-local}" = local ] && [ -n "$MODEL_ENDPOINT" ]; then
			model_host=$(printf '%s' "$MODEL_ENDPOINT" | sed -E 's#^https?://##; s#/.*$##; s#^\[(.*)\](:[0-9]+)?$#\1#; s#^([^:]*):[0-9]+$#\1#')
			case "$model_host" in
				127.*|::1|localhost) ;;
				*) die "--model-provider local listens on loopback only; a server elsewhere needs --model-class cloud (https)" ;;
			esac
		fi
		;;
	anthropic)
		[ -n "$MODEL_KEY_FILE" ] || die "--model-provider anthropic needs --model-key-file"
		[ -z "$MODEL_CLASS" ] || die "--model-class applies to --model-provider local only"
		;;
esac

# ---- TLS mode, listen address, names (contracts/runtime/tls-v1.md) -----------
if [ -z "$TLS_MODE" ] && [ -f "$ETC/core.env" ]; then
	# Upgrade: keep the mode and address; an instance from before TLS stays on loopback HTTP.
	TLS_MODE=$(env_value ANOS_TLS_MODE)
	TLS_MODE=${TLS_MODE:-http-local}
	[ -n "$LISTEN" ] || LISTEN=$(env_value ANOS_HTTP_ADDR | sed 's/:[0-9]*$//; s/^\[//; s/\]$//')
fi
TLS_MODE=${TLS_MODE:-https}
case "$TLS_MODE" in
	https|http-lan) LISTEN=${LISTEN:-0.0.0.0} ;;
	http-local)     LISTEN=${LISTEN:-127.0.0.1} ;;
	*) die "--tls must be https, http-local or http-lan (proxy-https is set by hand in core.env)" ;;
esac
printf '%s' "$LISTEN" | grep -Eqx '[0-9a-fA-F.:]+|localhost' || die "--listen must be an IP address"
if [ "$TLS_MODE" = http-local ]; then
	case "$LISTEN" in
		127.*|::1|localhost) ;;
		*) die "--tls http-local listens on loopback only; use --tls https (or http-lan) for $LISTEN" ;;
	esac
fi
case "$LISTEN" in
	*:*) HTTP_ADDR="[$LISTEN]:$PORT" ;;
	*)   HTTP_ADDR="$LISTEN:$PORT" ;;
esac
# The installer reaches Core on loopback unless it listens on one address only.
case "$LISTEN" in
	0.0.0.0|::|localhost) CHECK_HOST=127.0.0.1 ;;
	*:*) CHECK_HOST="[$LISTEN]" ;;
	*) CHECK_HOST=$LISTEN ;;
esac

[ -n "$TLS_NAMES" ] || TLS_NAMES=$(env_value ANOS_TLS_NAMES)
if [ -z "$TLS_NAMES" ]; then
	# This machine's names and addresses, as other devices are likely to type them.
	TLS_NAMES=$(
		{
			hostname -s 2>/dev/null || true
			hostname -f 2>/dev/null | grep '\.' || true
			hostname -I 2>/dev/null | tr ' ' '\n' || true
		} | tr 'A-Z' 'a-z' | grep -Ex '[a-z0-9][a-z0-9.-]*[a-z0-9]|[0-9a-f:]*:[0-9a-f:]+' | grep -v '^fe80:' | paste -sd, -
	)
fi
# Loopback names are always there (the installer's health check, access on the server itself), and so is a
# single listen address.
for n in localhost 127.0.0.1 ::1 "$LISTEN"; do
	case "$n" in 0.0.0.0|::) continue ;; esac
	case ",$TLS_NAMES," in *",$n,"*) ;; *) TLS_NAMES="${TLS_NAMES:+$TLS_NAMES,}$n" ;; esac
done

# SQL goes to psql on stdin, not in arguments (later writes include the password).
pg_sql() {
	(
		cd /
		unset PGHOST PGHOSTADDR PGSERVICE PGUSER
		runuser -u postgres -- psql -p "$PG_PORT" -v ON_ERROR_STOP=1 -qAtX -d "${1:-postgres}" -f -
	)
}

pg_num=$(printf '%s\n' "SHOW server_version_num;" | pg_sql) ||
	die "cannot reach the PostgreSQL cluster at port $PG_PORT (set ANOS_PG_PORT)"
printf '%s' "$pg_num" | grep -Eqx '[0-9]+' || die "unexpected PostgreSQL version '$pg_num' at port $PG_PORT"
[ "$pg_num" -ge 160000 ] || die "PostgreSQL at port $PG_PORT is $pg_num: AnOS needs 16 or later"

# ---- binaries: taken from the prebuilt payload ----------------------------------
BUILD=$(mktemp -d /tmp/anos-build.XXXXXX)
trap 'rm -rf "$BUILD"' EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
HAVE_CORE=1

say "installing the prebuilt files of $PREBUILT"
cp "$PREBUILT/bin/$AGENT_ARTIFACT" "$BUILD/anos-agent"
cp "$PREBUILT/bin/$CORE_ARTIFACT" "$BUILD/anos-core"

# ---- platform schema preflight (D-74) -------------------------------------
platform_compatible() { # target Core, allow downgrade (0 or 1)
	"$1" platform-migrations >"$BUILD/known-migrations" ||
		{ warn "cannot list the target Core's platform migrations"; return 1; }
	[ -s "$BUILD/known-migrations" ] ||
		{ warn "the target Core's platform migration list is empty"; return 1; }
	if ! pg_sql "$DB" >"$BUILD/applied-migrations" <<'SQL'
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SELECT format('SELECT %L || chr(9) || version FROM %I.schema_migrations', n.nspname, n.nspname)
FROM pg_catalog.pg_class AS c
JOIN pg_catalog.pg_namespace AS n ON n.oid = c.relnamespace
WHERE c.relname = 'schema_migrations' AND c.relkind IN ('r', 'p')
	AND left(n.nspname, 4) <> 'app_'
\gexec
COMMIT;
SQL
	then
		warn "cannot read the platform migration journals in $DB"
		return 1
	fi
	LC_ALL=C sort -u -o "$BUILD/known-migrations" "$BUILD/known-migrations" &&
	LC_ALL=C sort -u -o "$BUILD/applied-migrations" "$BUILD/applied-migrations" &&
	LC_ALL=C comm -23 "$BUILD/applied-migrations" "$BUILD/known-migrations" >"$BUILD/unknown-migrations" ||
		return 1
	if [ -s "$BUILD/unknown-migrations" ]; then
		warn "platform migrations applied in $DB but unknown to the target Core:"
		sed 's/^/    /' "$BUILD/unknown-migrations" >&2
		[ "$2" = 1 ] || { warn "platform downgrade refused; use --allow-platform-downgrade to proceed deliberately"; return 1; }
		warn "proceeding with --allow-platform-downgrade; applied migrations are retained"
	fi
}

db_exists=$(printf '%s\n' "SELECT 1 FROM pg_database WHERE datname = '$DB';" | pg_sql) ||
	die "cannot query the PostgreSQL cluster at port $PG_PORT"
if [ "$db_exists" = 1 ]; then
	case "$HAVE_CORE" in
		1) migration_core="$BUILD/anos-core" ;;
		2) migration_core="$OPT/bin/anos-core" ;;
		*) die "cannot check the platform migrations in $DB: target Core is missing" ;;
	esac
	platform_compatible "$migration_core" "$ALLOW_PLATFORM_DOWNGRADE" ||
		die "platform compatibility check failed for $DB"
fi

if [ -f "$ETC/core.env" ]; then
	v2_check_existing_config
	v2_activate
	exit 0
fi

# ---- OS identities --------------------------------------------------------
ensure_group() { getent group "$1" >/dev/null || groupadd --system "$1"; }
ensure_group "$CORE_USER"
ensure_group "$APPS_GROUP"
if getent passwd "$CORE_USER" >/dev/null; then
	usermod --append --groups "$APPS_GROUP" "$CORE_USER"
else
	useradd --system --gid "$CORE_USER" --groups "$APPS_GROUP" --no-create-home \
		--home-dir /nonexistent --shell /usr/sbin/nologin "$CORE_USER"
fi

# ---- directories (modes of contract section 1) ----------------------------
install -d -m 0755 /opt/anos "$OPT" "$OPT/bin" "$OPT/apps" "$OPT/ui-apps"
[ -d "$OPT/ui" ] || install -d -m 0755 "$OPT/ui"
install -d -m 0755 /etc/anos "$ETC" "$ETC/keys"
install -m 0644 -o root -g root /dev/null "$ETC/.runtime-rust"
install -d -m 0755 /var/lib/anos "$VAR" "$VAR/apps"
install -d -m 0750 -o "$CORE_USER" -g "$CORE_USER" "$VAR/core" "$VAR/core/incoming"
install -d -m 0700 "$VAR/agent"
install -d -m 0750 "$VAR/data"
# Packages (contracts/packages/v1.md "Thực thi"): the agent's immutable package store, the
# root-only EnvironmentFiles of apps with a database, and the trust roots (root-owned, not
# writable by anyone else: Core and the agent refuse them otherwise). catalog-trust holds the
# App Store catalog keys (contracts/core-api/appstore-v1.md).
install -d -m 0700 "$VAR/packages" "$ETC/apps"
install -d -m 0755 -o root -g root "$ETC/trust" "$ETC/agent-trust" "$ETC/catalog-trust"
# The official catalog and publisher keys go in with the activation (runtime-v2.sh v2_install_trust).

# ---- first-run setup code (created once; needed to create the first administrator). 128 random bits (SEC-4.30-07):
# a bearer secret until the first administrator exists, compared in constant time by Core (identity web.go setup).
if [ ! -s "$ETC/setup-code" ]; then
	( umask 077; head -c 16 /dev/urandom | od -An -tx1 | tr -d ' \n' >"$ETC/setup-code" )
fi
chown "root:$CORE_USER" "$ETC/setup-code"
chmod 0640 "$ETC/setup-code"

# ---- keys and installation id (created once) -----------------------------
"$BUILD/anos-agent" keygen --dir "$ETC/keys" >/dev/null
chown "root:$CORE_USER" "$ETC/keys/permit.key"
chmod 0640 "$ETC/keys/permit.key"
chown root:root "$ETC/keys/permit.pub"
chmod 0644 "$ETC/keys/permit.pub"

# Two-step sign-in: the key that encrypts TOTP secrets (hex, 32 bytes). Created once and kept:
# a new key would make every enrolled authenticator unreadable.
if [ ! -s "$ETC/keys/mfa.key" ]; then
	( umask 077; od -An -N32 -tx1 /dev/urandom | tr -d ' \n' >"$ETC/keys/mfa.key.tmp.$$" )
	mv -f "$ETC/keys/mfa.key.tmp.$$" "$ETC/keys/mfa.key"
fi
chown "root:$CORE_USER" "$ETC/keys/mfa.key"
chmod 0640 "$ETC/keys/mfa.key"

# The anos-core that is being installed (or the one kept when the new one does not build).
CORE_BIN=""
[ "$HAVE_CORE" = 1 ] && CORE_BIN="$BUILD/anos-core"
[ "$HAVE_CORE" = 2 ] && CORE_BIN="$OPT/bin/anos-core"

# Backup key (contracts/runtime/backup-v1.md): authenticates backup sets; root only, created once.
if [ ! -s "$ETC/keys/backup.key" ]; then
	rm -f "$ETC/keys/backup.key"
	if [ -n "$CORE_BIN" ]; then
		"$CORE_BIN" backup keygen --key "$ETC/keys/backup.key" >/dev/null ||
			warn "could not create the backup key $ETC/keys/backup.key"
	fi
fi
if [ ! -s "$ETC/keys/backup.key" ]; then
	die "could not provision the backup key"
fi
if [ -f "$ETC/keys/backup.key" ]; then
	chown root:root "$ETC/keys/backup.key"
	chmod 0600 "$ETC/keys/backup.key"
fi

if [ ! -s "$ETC/installation-id" ]; then
	cat /proc/sys/kernel/random/uuid >"$ETC/installation-id"
fi
chmod 0644 "$ETC/installation-id"
IID=$(cat "$ETC/installation-id")

# ---- TLS certificate (https only; contracts/runtime/tls-v1.md) ----------------
if [ "$TLS_MODE" = https ]; then
	[ -n "$CORE_BIN" ] || die "--tls https needs anos-core to create the certificate, and it does not build"
	"$CORE_BIN" tls ensure -dir "$ETC/tls" -instance "$INST" -names "$TLS_NAMES" -group "$CORE_USER" ||
		die "cannot create or renew the TLS certificate in $ETC/tls (names: $TLS_NAMES)"
fi

# ---- PostgreSQL: database and role ---------------------------------------
# The password is random, lives only in core.env and is never printed.
DB_PASS=""
if [ -f "$ETC/core.env" ]; then
	DB_PASS=$(sed -n "s|^ANOS_DATABASE_URL=postgres://$DB_ROLE:\\([0-9a-f]\\{32,\\}\\)@.*|\\1|p" "$ETC/core.env" | head -n 1)
fi
[ -n "$DB_PASS" ] || DB_PASS=$(od -An -N24 -tx1 /dev/urandom | tr -d ' \n')
[ ${#DB_PASS} -ge 32 ] || die "could not generate a database password"

pg_sql <<EOF || die "cannot create role $DB_ROLE on the PostgreSQL cluster at port $PG_PORT"
DO \$\$ BEGIN
	IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '$DB_ROLE') THEN
		CREATE ROLE $DB_ROLE LOGIN;
	END IF;
END \$\$;
ALTER ROLE $DB_ROLE LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD '$DB_PASS';
EOF
if [ "$db_exists" != 1 ]; then
	printf '%s\n' "CREATE DATABASE $DB OWNER $DB_ROLE;" | pg_sql || die "cannot create database $DB"
fi
printf '%s\n' "REVOKE ALL ON DATABASE $DB FROM PUBLIC;" | pg_sql || die "cannot restrict database $DB"

# App databases (contracts/packages/v1.md "Thực thi"): a NOLOGIN provisioner role owns the one
# SECURITY DEFINER function Core may call to create an app's role and schema; Core itself stays
# NOCREATEROLE. The SQL is generated by the anos-core that is being installed.
PROVISIONED=0
if [ "$HAVE_CORE" = 1 ]; then
	"$BUILD/anos-core" packages provision-sql --instance "$INST" --database "$DB" --core-role "$DB_ROLE" >"$BUILD/provision.sql" &&
		pg_sql "$DB" <"$BUILD/provision.sql" >/dev/null &&
		PROVISIONED=1 ||
		warn "could not install the app database provisioning in $DB; packages with migrations will fail"
fi

if [ "$PROVISIONED" != 1 ]; then
	die "app database provisioning failed for $DB"
fi

# ---- configuration --------------------------------------------------------
write_file() { # write_file <path> <mode> <group>; content on stdin
	tmp="$1.tmp.$$"
	(umask 077 && cat >"$tmp")
	chown "root:$3" "$tmp"
	chmod "$2" "$tmp"
	mv -f "$tmp" "$1"
}

# Settings an operator adds by hand and the installer keeps: the App Store catalog. --catalog replaces it; the Rust
# runtime, which has no built-in apps, defaults to the official catalog.
CATALOG_SOURCE=$(env_value ANOS_CATALOG_SOURCE)
if [ -n "$CATALOG_OPT" ]; then
	CATALOG_SOURCE=$CATALOG_OPT
elif [ -z "$CATALOG_SOURCE" ]; then
	CATALOG_SOURCE=$V2_OFFICIAL_CATALOG
fi
CATALOG_CHANNEL=$(env_value ANOS_CATALOG_CHANNEL)

{
	cat <<EOF
# AnOS Core, instance $INST. Written by tools/install/install.sh; contains the database password.
ANOS_INSTANCE=$INST
ANOS_HTTP_ADDR=$HTTP_ADDR
# https: Core serves TLS from ANOS_TLS_DIR; http-local: loopback HTTP; http-lan: HTTP on the network (warned).
ANOS_TLS_MODE=$TLS_MODE
ANOS_TLS_DIR=$ETC/tls
ANOS_TLS_NAMES=$TLS_NAMES
ANOS_DATABASE_URL=postgres://$DB_ROLE:$DB_PASS@127.0.0.1:$PG_PORT/$DB?sslmode=disable
ANOS_UI_DIR=$OPT/ui
ANOS_RUN_DIR=$RUN
ANOS_STATE_DIR=$VAR/core
ANOS_PERMIT_KEY_FILE=$ETC/keys/permit.key
ANOS_MFA_KEY_FILE=$ETC/keys/mfa.key
ANOS_INSTALLATION_ID=$IID
ANOS_PERMIT_TTL_SECONDS=30
ANOS_UI_APPS_DIR=$OPT/ui-apps
ANOS_SETUP_CODE_FILE=$ETC/setup-code
# Package manager: publisher keys Core accepts (uploads land in \$ANOS_STATE_DIR/incoming).
ANOS_TRUST_DIR=$ETC/trust
# App Store: catalog keys; ANOS_CATALOG_SOURCE (kept on upgrade) names the catalog, empty = not configured.
ANOS_CATALOG_TRUST_DIR=$ETC/catalog-trust
EOF
	[ -z "$CATALOG_SOURCE" ] || printf 'ANOS_CATALOG_SOURCE=%s\n' "$CATALOG_SOURCE"
	[ -z "$CATALOG_CHANNEL" ] || printf 'ANOS_CATALOG_CHANNEL=%s\n' "$CATALOG_CHANNEL"
	if [ "$DEV_TOOLS" = 1 ]; then
		printf '%s\n' "# Development tools: /api/v1/dev/* for administrators (status page). install.sh --no-dev-tools removes it." \
			"ANOS_DEV_TOOLS=1"
	fi
	if [ "$MODEL_PROVIDER" != none ]; then
		printf '%s\n' "# Model gateway (contracts/core-api/model-v1.md section 7); kept on upgrade, install.sh --model-provider none removes it." \
			"ANOS_MODEL_PROVIDER=$MODEL_PROVIDER"
		[ -z "$MODEL_KEY_FILE" ] || printf 'ANOS_MODEL_KEY_FILE=%s\n' "$MODEL_KEY_FILE"
		[ -z "$MODEL_ID" ] || printf 'ANOS_MODEL_ID=%s\n' "$MODEL_ID"
		[ -z "$MODEL_ENDPOINT" ] || printf 'ANOS_MODEL_ENDPOINT=%s\n' "$MODEL_ENDPOINT"
		[ -z "$MODEL_CLASS" ] || printf 'ANOS_MODEL_CLASS=%s\n' "$MODEL_CLASS"
	fi
} | write_file "$ETC/core.env" 0640 "$CORE_USER"
# The key file is the operator's: only its path is recorded and its mode checked. Core refuses one that other
# users can read and says why in the Settings app (AI model panel).
if [ -n "$MODEL_KEY_FILE" ]; then
	if [ ! -f "$MODEL_KEY_FILE" ]; then
		warn "model key file $MODEL_KEY_FILE does not exist yet: create it (one line) as root:$CORE_USER 0640, then restart anos-core@$INST"
	else
		key_mode=$(stat -c '%a %U:%G' "$MODEL_KEY_FILE")
		[ "$key_mode" = "640 root:$CORE_USER" ] || warn "model key file $MODEL_KEY_FILE is $key_mode; expected 640 root:$CORE_USER"
	fi
fi

write_file "$ETC/agent.env" 0600 root <<EOF
# AnOS Host Agent, instance $INST. Written by tools/install/install.sh.
ANOS_INSTANCE=$INST
ANOS_RUN_DIR=$RUN
ANOS_ROOT=$OPT
ANOS_DATA_DIR=$VAR/data
ANOS_APPS_STATE_DIR=$VAR/apps
ANOS_STATE_DIR=$VAR/agent
ANOS_PERMIT_PUB_FILE=$ETC/keys/permit.pub
ANOS_INSTALLATION_ID=$IID
# Packages: the agent's own trust root, the only directory it takes packages from, its store
# and the root-only EnvironmentFiles of app units.
ANOS_AGENT_TRUST_DIR=$ETC/agent-trust
ANOS_CORE_INCOMING_DIR=$VAR/core/incoming
ANOS_PACKAGES_DIR=$VAR/packages
ANOS_APPS_ENV_DIR=$ETC/apps
EOF

install -d -m 0755 -o root -g root /var/backups/anos
install -d -m 0700 -o root -g root "/var/backups/anos/$INST"
v2_activate
