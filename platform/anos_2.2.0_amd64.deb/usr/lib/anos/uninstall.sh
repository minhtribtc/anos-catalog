#!/bin/sh
# Removes one AnOS instance: units (including generated app units), OS users and
# groups, and every directory of the instance.
#
#   uninstall.sh <instance> [--purge]
#
# Without --purge the PostgreSQL database and role are kept (the next install
# reuses the database and sets a new password). --purge drops both, on the port of the
# instance's core.env (ANOS_PG_PORT overrides it; default 9432).
# Run as root. Safe to run on a partially installed or already removed instance.
set -eu

PG_PORT=${ANOS_PG_PORT:-9432}

say()  { printf '%s\n' "uninstall: $*"; }
warn() { printf '%s\n' "uninstall: WARNING: $*" >&2; }
die()  { printf '%s\n' "uninstall: ERROR: $*" >&2; exit 1; }
usage() { printf '%s\n' "usage: uninstall.sh <instance> [--purge]" >&2; exit 2; }

INST=""
PURGE=0
while [ $# -gt 0 ]; do
	case "$1" in
		--purge) PURGE=1; shift ;;
		-*) usage ;;
		*) [ -z "$INST" ] || usage; INST=$1; shift ;;
	esac
done
[ -n "$INST" ] || usage
# The name goes into rm -rf paths and SQL below: nothing but the contract form passes.
printf '%s' "$INST" | grep -Eqx '[a-z][a-z0-9]{0,15}' ||
	die "instance name '$INST' must match [a-z][a-z0-9]{0,15}"
[ "$(id -u)" = 0 ] || die "must run as root"

CORE_USER="anos-$INST"
APPS_GROUP="anos-$INST-apps"

# Use the same instance lock as the installer so activation and removal cannot race.
install -d -m 0700 -o root -g root /run/anos-install
exec 9>"/run/anos-install/$INST.lock"
flock -x -w 60 9 || die "another installer or uninstaller is running for $INST"

# The cluster the instance uses (install.sh may have found a port other than 9432): read it before
# /etc/anos/<inst> goes away.
if [ -z "${ANOS_PG_PORT:-}" ] && [ -f "/etc/anos/$INST/core.env" ]; then
	p=$(sed -n 's|^ANOS_DATABASE_URL=postgres://[^@]*@[^:/]*:\([0-9][0-9]*\)/.*|\1|p' "/etc/anos/$INST/core.env" | head -n 1)
	PG_PORT=${p:-$PG_PORT}
fi

# ---- units ----------------------------------------------------------------
# Instance names contain no dash, so the prefix anos-app-<inst>- is unambiguous.
# The system updater first (docs/adr/0055): it must not start an update while the instance goes away.
systemctl disable --now "anos-updater@$INST.service" >/dev/null 2>&1 || true
systemctl disable --now "anos-tls-renew@$INST.timer" >/dev/null 2>&1 || true
systemctl disable --now "anos-backup@$INST.timer" >/dev/null 2>&1 || true
systemctl stop "anos-backup@$INST.service" >/dev/null 2>&1 || true
systemctl disable --now "anos-core@$INST.service" >/dev/null 2>&1 || true
app_units=$( {
	systemctl list-units --all --plain --no-legend "anos-app-$INST-*.service" 2>/dev/null | awk '{print $1}'
	for f in /run/systemd/system/anos-app-"$INST"-*.service; do
		[ -e "$f" ] && basename "$f"
	done
} | sort -u)
for u in $app_units; do
	systemctl stop "$u" >/dev/null 2>&1 || true
	rm -f "/run/systemd/system/$u"
done
systemctl disable --now "anos-agent@$INST.service" >/dev/null 2>&1 || true
SHARED_UNIT_CLEANUP=0
if [ -f "/etc/anos/$INST/core.env" ] && [ ! -f "/etc/anos/$INST/.runtime-rust" ]; then
	SHARED_UNIT_CLEANUP=1
fi
V2_UNITS_REMOVED=0
for u in "anos-agent@$INST.service" "anos-core@$INST.service" "anos-tls-renew@$INST.service" "anos-tls-renew@$INST.timer" \
	"anos-backup@$INST.service" "anos-backup@$INST.timer" "anos-updater@$INST.service"; do
	fragment="/etc/systemd/system/$u"
	if [ -f "$fragment" ] && [ ! -L "$fragment" ] &&
		[ "$(head -n 1 "$fragment")" = '# Managed by the AnOS v2 installer.' ]; then
		rm -f "$fragment"
		V2_UNITS_REMOVED=1
	fi
done
systemctl daemon-reload
for u in $app_units "anos-core@$INST.service" "anos-agent@$INST.service" "anos-tls-renew@$INST.service" "anos-tls-renew@$INST.timer" \
	"anos-backup@$INST.service" "anos-backup@$INST.timer" "anos-updater@$INST.service"; do
	systemctl reset-failed "$u" >/dev/null 2>&1 || true
done

# ---- users and groups -----------------------------------------------------
remove_user() {
	getent passwd "$1" >/dev/null || return 0
	if ! userdel "$1" >/dev/null 2>&1; then
		pkill -KILL -u "$1" >/dev/null 2>&1 || true
		sleep 1
		userdel "$1" || warn "could not remove user $1"
	fi
}
remove_group() {
	getent group "$1" >/dev/null || return 0
	groupdel "$1" || warn "could not remove group $1"
}
for u in $(getent passwd | cut -d: -f1 | grep -E "^anos-$INST-app-[a-z][a-z0-9-]{0,31}\$" || true); do
	remove_user "$u"
	remove_group "$u"
done
remove_user "$CORE_USER"
remove_group "$CORE_USER"
remove_group "$APPS_GROUP"

# ---- directories ----------------------------------------------------------
rm -rf "/etc/anos/$INST" "/opt/anos/$INST" "/var/lib/anos/$INST" "/run/anos/$INST" "/run/anos-updater/$INST"
for d in /etc/anos /opt/anos /var/lib/anos /run/anos /run/anos-updater; do
	rmdir "$d" 2>/dev/null || true # only when no other instance is left
done

# The unit templates are shared by all instances: remove them with the last one.
if [ "$V2_UNITS_REMOVED" = 0 ] && [ "$SHARED_UNIT_CLEANUP" = 1 ] && [ ! -d /etc/anos ]; then
	rm -f /etc/systemd/system/anos-core@.service /etc/systemd/system/anos-agent@.service \
		/etc/systemd/system/anos-tls-renew@.service /etc/systemd/system/anos-tls-renew@.timer \
		/etc/systemd/system/anos-backup@.service /etc/systemd/system/anos-backup@.timer
	systemctl daemon-reload
fi

# The scheduled backup sets (/var/backups/anos/<inst>) are never removed here: they may be all that is left of the
# instance. Delete them by hand when they are no longer needed.
if [ -d "/var/backups/anos/$INST" ] && [ -n "$(ls -A "/var/backups/anos/$INST" 2>/dev/null)" ]; then
	say "the backup sets in /var/backups/anos/$INST are kept"
fi

# ---- database -------------------------------------------------------------
if [ "$PURGE" = 1 ]; then
	(cd / && su postgres -c "psql -p $PG_PORT -v ON_ERROR_STOP=1 -qAtX -d postgres -f -") <<SQL ||
DROP DATABASE IF EXISTS anos_$INST WITH (FORCE);
DROP DATABASE IF EXISTS anos_${INST}_preupdate WITH (FORCE);
DROP ROLE IF EXISTS anos_${INST}_core;
-- App roles (contracts/packages/v1.md "Thực thi") and the provisioner that created them.
DO \$\$ DECLARE r text; BEGIN
	FOR r IN SELECT rolname FROM pg_roles WHERE rolname LIKE 'anos\\_${INST}\\_app\\_%' LOOP
		EXECUTE format('DROP ROLE %I', r);
	END LOOP;
END \$\$;
DROP ROLE IF EXISTS anos_${INST}_provision;
SQL
		die "could not drop database anos_$INST / role anos_${INST}_core on port $PG_PORT"
	say "instance $INST removed, database and roles dropped"
else
	say "instance $INST removed; database anos_$INST and its roles (core, provision, app roles) are kept (use --purge to drop them)"
fi
