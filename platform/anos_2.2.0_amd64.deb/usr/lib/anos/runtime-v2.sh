#!/bin/sh
# Loaded by install.sh for explicit native v2 installs, and by anos-instance for `apps`.

# Apps come from the catalog (docs/adr/0051): the official one, and the baseline every instance installs (the Core
# command installs backends before UIs).
V2_OFFICIAL_CATALOG=https://minhtribtc.github.io/anos-catalog/
V2_BASELINE_APPS=anos.store,anos.accounts,anos.settings,anos.notifications,anos.files
# Standalone pages of the built-in apps of 2.0.2; their packages serve them now.
V2_LEGACY_UI_DIRS="accounts files settings"

v2_preflight_files() {
	[ -d /run/systemd/system ] && systemctl show -p Version >/dev/null ||
		die "--runtime rust requires a running systemd system manager"
	invalid_ui=$(find "$PREBUILT/ui" ! -type d ! -type f -print -quit) ||
		die "cannot inspect the prebuilt UI"
	[ -z "$invalid_ui" ] || die "the prebuilt UI must contain only regular files and directories"
	v2_trust_source >/dev/null
	[ -x "$PREBUILT/bin/anos-updater" ] || die "ANOS_PREBUILT_DIR: $PREBUILT/bin/anos-updater is missing"
	v2_check_platform_version
	V2_UNITS="anos-agent@$INST.service anos-core@$INST.service anos-tls-renew@$INST.service anos-tls-renew@$INST.timer anos-backup@$INST.service anos-backup@$INST.timer anos-updater@$INST.service"
	for unit in $V2_UNITS; do
		template=$(v2_template "$unit")
		[ -r "$template" ] || die "unit template is missing: $template"
		fragment="/etc/systemd/system/$unit"
		if [ -e "$fragment" ] || [ -L "$fragment" ]; then
			[ -f "$fragment" ] && [ ! -L "$fragment" ] &&
				[ "$(head -n 1 "$fragment")" = "$V2_UNIT_HEADER" ] ||
				die "existing instance unit is managed separately: $fragment"
		fi
	done
}

# The platform version of the payload (BUILDINFO, Debian "~" read as semver "-"), written to $OPT/VERSION; the
# system updater (docs/adr/0055) compares it with the signed platform list. A lower version than the installed
# one is refused without --allow-platform-downgrade; the same version reinstalls (repair). While the updater of
# this instance runs an update, only that update's own installer run (ANOS_UPDATER_JOB) may proceed.
v2_check_platform_version() {
	V2_PLATFORM_VERSION=$(sed -n 's/^version=//p' "$PREBUILT/BUILDINFO" 2>/dev/null | head -n 1 | tr '~' '-')
	if [ -z "${ANOS_UPDATER_JOB:-}" ] && [ -f "$VAR/updater/journal.json" ] &&
		grep -Eq '"state": "(running|rolling-back)"' "$VAR/updater/journal.json"; then
		die "a system update of $INST is in progress (anos-updater status); retry when it has finished"
	fi
	[ -n "$V2_PLATFORM_VERSION" ] && [ -f "$OPT/VERSION" ] || return 0
	installed=$(head -n 1 "$OPT/VERSION")
	[ -n "$installed" ] || return 0
	command -v dpkg >/dev/null || { warn "dpkg is missing: the platform version is not compared"; return 0; }
	if dpkg --compare-versions "$(printf '%s' "$V2_PLATFORM_VERSION" | tr '-' '~')" lt "$(printf '%s' "$installed" | tr '-' '~')"; then
		[ "$ALLOW_PLATFORM_DOWNGRADE" = 1 ] ||
			die "$INST runs platform $installed; installing the older $V2_PLATFORM_VERSION requires --allow-platform-downgrade"
		warn "installing the older platform $V2_PLATFORM_VERSION over $installed (--allow-platform-downgrade)"
	fi
}

v2_template() {
	case "$1" in
		anos-backup@*) printf '%s/deploy/systemd/anos-backup@.%s\n' "$INSTALL_ROOT" "${1##*.}"; return ;;
	esac
	printf '%s/deploy/systemd/v2/%s@.%s\n' "$INSTALL_ROOT" "${1%@*}" "${1##*.}"
}

v2_check_existing_config() {
	[ "$db_exists" = 1 ] && [ -f "$ETC/agent.env" ] ||
		die "existing instance requires its original database and both environment files"
	[ "$MODEL_OPTIONS" = 0 ] &&
		{ [ "$V2_TLS_NAMES_SET" = 0 ] || [ "$TLS_NAMES" = "$(env_value ANOS_TLS_NAMES)" ]; } ||
		die "v2 upgrade preserves the existing TLS names and model configuration"
	original_dev_tools=0
	[ "$(env_value ANOS_DEV_TOOLS)" != 1 ] || original_dev_tools=1
	[ -z "$REQUESTED_DEV_TOOLS" ] || [ "$REQUESTED_DEV_TOOLS" = "$original_dev_tools" ] ||
		die "v2 upgrade preserves the existing development tools setting"
	original_pg_port=$(env_value ANOS_DATABASE_URL | sed -n "s|^postgres://$DB_ROLE:[^@]*@127\.0\.0\.1:\([0-9][0-9]*\)/$DB?sslmode=disable$|\1|p")
	[ "$PG_PORT" = "$original_pg_port" ] ||
		die "v2 upgrade requires the existing instance's local PostgreSQL connection"
	original_tls_mode=$(env_value ANOS_TLS_MODE)
	[ "$TLS_MODE" = "${original_tls_mode:-http-local}" ] &&
		[ "$HTTP_ADDR" = "$(env_value ANOS_HTTP_ADDR)" ] ||
		die "v2 upgrade preserves the existing listen address, port and TLS mode"
}

v2_save_file() {
	path=$1
	if [ -e "$path" ] || [ -L "$path" ]; then
		mkdir -p "$BUILD/previous$(dirname "$path")"
		cp -a "$path" "$BUILD/previous$path"
	fi
	printf '%s\n' "$path" >>"$BUILD/replaced-files"
}

v2_wait_healthy() {
	for attempt in $(seq 1 60); do
		if systemctl is-active --quiet "anos-agent@$INST.service" &&
			systemctl is-active --quiet "anos-core@$INST.service" &&
			curl -fsS --noproxy "*" --max-time 1 --unix-socket "$RUN/agent-control.sock" http://agent/agent/v0/status >/dev/null 2>&1 &&
			{ if [ "$TLS_MODE" = https ]; then
				curl -fsS --noproxy "*" --max-time 1 --cacert "$ETC/tls/ca-bundle.crt" "$URL/healthz"
			else
				curl -fsS --noproxy "*" --max-time 1 "$URL/healthz"
			fi; } >/dev/null 2>&1; then
			return 0
		fi
		sleep 0.5
	done
	return 1
}

v2_start_unit() {
	if systemctl start "$1"; then
		return 0
	fi
	# An explicit activation can follow a recovered crash loop while systemd
	# still counts its starts. Reset only that unit's counter and retry once.
	[ "$(systemctl show -p Result --value "$1")" = start-limit-hit ] || return 1
	systemctl reset-failed "$1" && systemctl start "$1"
}

v2_restore_unit_state() {
	while IFS=" " read -r unit active enabled; do
		if [ "$enabled" = enabled ]; then
			systemctl enable --force --quiet "$unit" || return 1
		elif systemctl is-enabled --quiet "$unit"; then
			systemctl disable --quiet "$unit" || return 1
		fi
		if [ "$active" = active ]; then
			if systemctl is-failed --quiet "$unit"; then systemctl reset-failed "$unit" || return 1; fi
			v2_start_unit "$unit" || return 1
		fi
	done <"$BUILD/unit-state"
}

v2_restore() {
	if [ "$V2_SWITCHING" = 0 ]; then
		if [ "$V2_PAUSING" = 1 ]; then
			while IFS=" " read -r unit active enabled; do
				case "$unit:$active" in *.timer:active) systemctl start "$unit" || return 1 ;; esac
			done <"$BUILD/unit-state"
		fi
		return 0
	fi
	warn "v2 activation failed; checking whether the previous runtime can be restored"
	for unit in "anos-backup@$INST.timer" "anos-tls-renew@$INST.timer" "anos-core@$INST.service" "anos-agent@$INST.service"; do
		systemctl stop "$unit" 2>/dev/null ||
			[ "$(systemctl show -p LoadState --value "$unit" 2>/dev/null)" = not-found ] ||
			return 1
	done
	if [ "$V2_STARTED" = 1 ] && [ -x "$BUILD/previous$OPT/bin/anos-core" ] &&
		! platform_compatible "$BUILD/previous$OPT/bin/anos-core" 0; then
		warn "previous Core cannot be restored safely with the current database journals"
		systemctl disable --quiet "anos-core@$INST.service" "anos-agent@$INST.service" || true
		return 1
	fi

	# Disable symlinks pointing to the candidate fragments before replacing them.
	while IFS=" " read -r unit active enabled; do
		[ "$enabled" = enabled ] || ! systemctl is-enabled --quiet "$unit" ||
			systemctl disable --quiet "$unit" || return 1
	done <"$BUILD/unit-state"
	while IFS= read -r path; do
		if [ -e "$BUILD/previous$path" ] || [ -L "$BUILD/previous$path" ]; then
			cp -a --remove-destination "$BUILD/previous$path" "$path" || return 1
		else
			rm -f "$path" || return 1
		fi
	done <"$BUILD/replaced-files"
	if [ -d "$V2_PREVIOUS_UI" ]; then
		if [ -d "$OPT/ui" ]; then
			mv -T "$OPT/ui" "$V2_NEXT_UI" || return 1
		fi
		mv -T "$V2_PREVIOUS_UI" "$OPT/ui" || return 1
	fi
	systemctl daemon-reload || return 1
	v2_restore_unit_state || return 1
	if grep -Fq "anos-core@$INST.service active " "$BUILD/unit-state"; then
		v2_wait_healthy || return 1
	fi
	say "previous service and payload state restored"
}

v2_finish() {
	status=$?
	trap - EXIT
	if [ "$status" != 0 ] && ! v2_restore; then
		warn "activation recovery incomplete; saved payload and unit state: $BUILD"
		warn "UI staging paths: $V2_PREVIOUS_UI and $V2_NEXT_UI"
		exit "$status"
	fi
	rm -rf "$V2_NEXT_UI" "$V2_PREVIOUS_UI" "$BUILD"
	exit "$status"
}

v2_activate() {
	V2_NEXT_UI="$OPT/.ui-v2-next.$(basename "$BUILD")"
	V2_PREVIOUS_UI="$OPT/.ui-v2-previous.$(basename "$BUILD")"
	V2_PAUSING=0
	V2_SWITCHING=0
	V2_STARTED=0
	trap 'v2_finish' EXIT
	trap 'exit 129' HUP
	trap 'exit 130' INT
	trap 'exit 143' TERM
	URL="$([ "$TLS_MODE" != https ] && printf http || printf https)://$CHECK_HOST:$PORT"

	: >"$BUILD/replaced-files"
	for unit in $V2_UNITS; do
		v2_save_file "/etc/systemd/system/$unit"
	done
	v2_save_file "$OPT/bin/anos-agent"
	v2_save_file "$OPT/bin/anos-core"
	v2_save_file "$OPT/bin/anos-updater"
	v2_save_file "$OPT/VERSION"
	for key in "$ETC/catalog-trust/anos-catalog.pub" "$ETC/trust/anos-publisher.pub" \
		"$ETC/agent-trust/anos-publisher.pub" "$ETC/core.env"; do
		v2_save_file "$key"
	done

	mkdir "$V2_NEXT_UI"
	cp -R "$PREBUILT/ui/." "$V2_NEXT_UI/"
	# Upgrade from 2.0.2: its standalone app pages stay until the baseline packages are installed.
	for dir in $V2_LEGACY_UI_DIRS; do
		if [ ! -e "$V2_NEXT_UI/$dir" ] && [ -d "$OPT/ui/$dir" ]; then
			cp -R "$OPT/ui/$dir" "$V2_NEXT_UI/$dir"
		fi
	done
	chown -R root:root "$V2_NEXT_UI"
	find "$V2_NEXT_UI" -type d -exec chmod 0755 {} +
	find "$V2_NEXT_UI" -type f -exec chmod 0644 {} +
	unit_state() {
		active=inactive
		enabled=disabled
		systemctl is-active --quiet "$1" && active=active
		systemctl is-enabled --quiet "$1" && enabled=enabled
		printf '%s %s %s\n' "$1" "$active" "$enabled"
	}
	# Agent before Core on restart. Timers follow the services.
	for unit in "anos-agent@$INST.service" "anos-core@$INST.service" \
		"anos-tls-renew@$INST.timer" "anos-backup@$INST.timer" "anos-updater@$INST.service"; do
		unit_state "$unit"
	done >"$BUILD/unit-state"

	# Pause the timers before checking for a job, so the jobs cannot begin while
	# the installer is replacing binaries. The exit trap also restores timers if
	# we abort before stopping the services.
	V2_PAUSING=1
	for unit in "anos-backup@$INST.timer" "anos-tls-renew@$INST.timer"; do
		if systemctl is-active --quiet "$unit"; then systemctl stop "$unit"; fi
	done
	for job in "anos-backup@$INST.service" "anos-tls-renew@$INST.service"; do
		case "$(systemctl show "$job" -p ActiveState --value)" in
			inactive|failed) ;;
			*) die "unit $job is busy; wait for it to finish before upgrading" ;;
		esac
	done
	V2_SWITCHING=1
	for unit in "anos-core@$INST.service" "anos-agent@$INST.service"; do
		if systemctl is-active --quiet "$unit"; then systemctl stop "$unit"; fi
	done
	# Recheck once the previous Core is stopped, before publishing candidate files.
	if [ "$db_exists" = 1 ]; then
		platform_compatible "$BUILD/anos-core" "$ALLOW_PLATFORM_DOWNGRADE" ||
			die "platform compatibility check failed after stopping the previous Core"
	fi

	install -m 0755 -o root -g root "$BUILD/anos-agent" "$OPT/bin/anos-agent.new"
	mv -Tf "$OPT/bin/anos-agent.new" "$OPT/bin/anos-agent"
	install -m 0755 -o root -g root "$BUILD/anos-core" "$OPT/bin/anos-core.new"
	mv -Tf "$OPT/bin/anos-core.new" "$OPT/bin/anos-core"
	install -m 0755 -o root -g root "$PREBUILT/bin/anos-updater" "$OPT/bin/anos-updater.new"
	mv -Tf "$OPT/bin/anos-updater.new" "$OPT/bin/anos-updater"
	if [ -n "$V2_PLATFORM_VERSION" ]; then
		printf '%s\n' "$V2_PLATFORM_VERSION" >"$OPT/VERSION.new"
		chmod 0644 "$OPT/VERSION.new"
		mv -Tf "$OPT/VERSION.new" "$OPT/VERSION"
	fi
	mv -T "$OPT/ui" "$V2_PREVIOUS_UI"
	mv -T "$V2_NEXT_UI" "$OPT/ui"
	v2_install_trust
	v2_set_catalog_source
	for unit in $V2_UNITS; do
		{
			case "$unit" in anos-backup@*) printf '%s\n' "$V2_UNIT_HEADER";; esac
			cat "$(v2_template "$unit")"
		} >"$BUILD/unit-$unit"
		install -m 0644 -o root -g root "$BUILD/unit-$unit" "/etc/systemd/system/$unit.new"
		mv -Tf "/etc/systemd/system/$unit.new" "/etc/systemd/system/$unit"
	done
	systemctl daemon-reload
	V2_STARTED=1
	v2_start_unit "anos-agent@$INST.service"
	v2_start_unit "anos-core@$INST.service"
	if ! v2_wait_healthy; then
		journalctl -u "anos-agent@$INST.service" -u "anos-core@$INST.service" -n 20 --no-pager >&2 || true
		die "Rust Core or Host Agent did not become healthy at $URL"
	fi
	systemctl enable --force --quiet "anos-agent@$INST.service" "anos-core@$INST.service"
	if [ "$TLS_MODE" = https ]; then
		systemctl enable --force --quiet --now "anos-tls-renew@$INST.timer"
	else
		systemctl disable --quiet "anos-tls-renew@$INST.timer"
	fi
	backup_timer="anos-backup@$INST.timer"
	if [ -s "$ETC/keys/backup.key" ]; then
		if [ "$db_exists" != 1 ]; then
			systemctl enable --force --quiet --now "$backup_timer"
		else
			timer_state=$(awk -v unit="$backup_timer" '$1 == unit { print $2, $3 }' "$BUILD/unit-state")
			case "$timer_state" in
				'active enabled') systemctl enable --force --quiet --now "$backup_timer" ;;
				'inactive enabled') systemctl enable --force --quiet "$backup_timer" ;;
				'active disabled') systemctl start "$backup_timer" ;;
			esac
		fi
	elif systemctl is-enabled --quiet "$backup_timer"; then
		systemctl disable --quiet "$backup_timer"
	fi
	v2_start_updater
	say "Rust Core and Host Agent of $INST are running: $URL"
	# The platform is in place: from here a failure leaves it running and reports PARTIAL instead of rolling back.
	V2_SWITCHING=0
	V2_PAUSING=0
	if ! v2_bootstrap_apps "$CATALOG_OPT" "$PREBUILT/ui"; then
		warn "instance $INST is only partially installed: baseline-missing"
		v2_retry_hint "$CATALOG_OPT"
		exit 3
	fi
	say "instance $INST is ready with Rust Core and Host Agent: $URL"
}

# The system updater (docs/adr/0055) runs with the installed binary. Run by the updater itself (ANOS_UPDATER_JOB),
# the installer only enables it: the updater restarts on its own once the update has finished, and a restart here
# would end the update that is running this installer.
v2_start_updater() {
	updater="anos-updater@$INST.service"
	systemctl enable --quiet "$updater"
	[ -z "${ANOS_UPDATER_JOB:-}" ] || return 0
	if systemctl is-active --quiet "$updater"; then
		systemctl restart "$updater"
	else
		v2_start_unit "$updater"
	fi
}

# The official keys: the package's trust/ (prebuilt), else deploy/deb/trust of the source tree.
v2_trust_source() {
	for dir in "$PREBUILT/trust" "$INSTALL_ROOT/deploy/deb/trust"; do
		if [ -s "$dir/catalog.pub" ] && [ -s "$dir/publisher.pub" ]; then
			printf '%s\n' "$dir"
			return 0
		fi
	done
	die "the official catalog and publisher keys are missing (looked in $PREBUILT/trust and $INSTALL_ROOT/deploy/deb/trust)"
}

# Trust roots must be root-owned and not writable by group or others: Core and the agent refuse them otherwise.
v2_install_trust() {
	trust_src=$(v2_trust_source)
	for dir in "$ETC/catalog-trust" "$ETC/trust" "$ETC/agent-trust"; do
		install -d -m 0755 -o root -g root "$dir"
		chown root:root "$dir"
		chmod 0755 "$dir"
	done
	install -m 0644 -o root -g root "$trust_src/catalog.pub" "$ETC/catalog-trust/anos-catalog.pub"
	install -m 0644 -o root -g root "$trust_src/publisher.pub" "$ETC/trust/anos-publisher.pub"
	install -m 0644 -o root -g root "$trust_src/publisher.pub" "$ETC/agent-trust/anos-publisher.pub"
}

# core.env keeps its catalog unless --catalog names another; one without a catalog gets the official one.
v2_set_catalog_source() {
	current=$(env_value ANOS_CATALOG_SOURCE)
	wanted=${CATALOG_OPT:-${current:-$V2_OFFICIAL_CATALOG}}
	[ "$wanted" != "$current" ] || return 0
	tmp="$ETC/core.env.tmp.$$"
	{
		grep -v '^ANOS_CATALOG_SOURCE=' "$ETC/core.env" || true
		printf 'ANOS_CATALOG_SOURCE=%s\n' "$wanted"
	} | (umask 077 && cat >"$tmp")
	chown "root:$CORE_USER" "$tmp"
	chmod 0640 "$tmp"
	mv -f "$tmp" "$ETC/core.env"
	say "App Store catalog: $wanted"
}

v2_retry_hint() {
	warn "the baseline apps ($V2_BASELINE_APPS) are not all installed; once the catalog is reachable, retry with:"
	warn "    anos-instance apps $INST${1:+ --catalog $1}"
}

# v2_bootstrap_apps <catalog or empty> <packaged UI dir>: installs the baseline apps from the catalog as the Core
# user, with core.env loaded; safe to repeat. A built-in app manifest left by 2.0.2 (manifest.json without the
# "current" link of a UI package) makes the agent refuse a package for that slug (SLUG_RESERVED), so those are set
# aside for the run. When the run fails, the ones of apps that are still not installed come back and the instance
# keeps working; after a complete run they and the old standalone pages are removed.
v2_bootstrap_apps() {
	bootstrap_source=$1
	packaged_ui=$2
	aside="$VAR/installer/builtin-ui-apps"
	install -d -m 0700 -o root -g root "$VAR/installer" "$aside"
	for manifest in "$OPT"/ui-apps/*/manifest.json; do
		[ -f "$manifest" ] || continue
		app_dir=$(dirname "$manifest")
		slug=$(basename "$app_dir")
		if [ -e "$app_dir/current" ] || [ -L "$app_dir/current" ]; then continue; fi
		install -d -m 0700 -o root -g root "$aside/$slug"
		mv -f "$manifest" "$aside/$slug/manifest.json"
	done
	# An upgrade from 2.0.2 installs every app the instance had built in, not only the baseline, so none of
	# them disappears from the Desktop (D-77: apps now come from the catalog).
	bootstrap_apps=$V2_BASELINE_APPS
	for saved in "$aside"/*/manifest.json; do
		[ -f "$saved" ] || continue
		app_id=$(sed -n 's/^[[:space:]]*"appId"[[:space:]]*:[[:space:]]*"\([a-z][a-z0-9.-]*\)".*/\1/p' "$saved" | head -n 1)
		case ",$bootstrap_apps," in *",$app_id,"*|,,) ;; *) [ -z "$app_id" ] || bootstrap_apps="$bootstrap_apps,$app_id" ;; esac
	done
	set -- --apps "$bootstrap_apps"
	[ -z "$bootstrap_source" ] || set -- "$@" --source "$bootstrap_source"
	say "installing apps from the catalog: $bootstrap_apps"
	bootstrap_ok=1
	(
		set -a
		# shellcheck disable=SC1091 # the instance's configuration, written by install.sh
		. "$ETC/core.env"
		set +a
		cd /
		exec runuser -u "$CORE_USER" -- "$OPT/bin/anos-core" appstore bootstrap "$@"
	) || bootstrap_ok=0
	for saved in "$aside"/*/manifest.json; do
		[ -f "$saved" ] || continue
		slug=$(basename "$(dirname "$saved")")
		app_dir="$OPT/ui-apps/$slug"
		if [ "$bootstrap_ok" = 0 ] && [ -d "$app_dir" ] && [ ! -e "$app_dir/current" ] && [ ! -L "$app_dir/current" ] &&
			[ ! -e "$app_dir/manifest.json" ]; then
			mv -f "$saved" "$app_dir/manifest.json"
			warn "kept the built-in app $slug"
		else
			rm -f "$saved"
			[ "$bootstrap_ok" = 0 ] || say "removed the built-in manifest of $slug"
		fi
		rmdir "$(dirname "$saved")"
	done
	rmdir "$aside" 2>/dev/null || true
	[ "$bootstrap_ok" = 1 ] || return 1
	for dir in $V2_LEGACY_UI_DIRS; do
		if [ -d "$OPT/ui/$dir" ] && [ ! -e "$packaged_ui/$dir" ]; then
			rm -rf "${OPT:?}/ui/$dir"
			say "removed the built-in standalone page /$dir/"
		fi
	done
	say "baseline apps installed"
}
